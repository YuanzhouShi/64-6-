$(function(){
    $(window).on("resize",function(){
        //1.1获取窗口宽度
        let clientW=$(window).width();
        //1.2设置临界值
        let isShowBigImage=clientW>=800;
        //1.3获取所有的item
        let $allItems=$("#lk_carousel .item");
        //1.4遍历
        $allItems.each(function (index, item){
            //1.4.1取出图片路径
            let src=isShowBigImage ? $(item).data("lg-img") : $(item).data("sm-img");
            let imgUrl='url("'+ src +'")';
            //1.4.2设置背景
            $(item).css({
                backgroundImage: imgUrl
            });
            //1.4.3设置img标签
            if(!isShowBigImage){
                let $img="<img src='"+ src +"'>";
                $(item).empty().append($img)
            }else{
                $(item).empty()
            }
        })
    })
    $(window).trigger("resize");
    //2.工具提示
    $('[data-toggle="tooltip"]').tooltip();
    //3.动态处理宽度
    $(window).on("resize",function(){
        let $ul=$("#lk_product .nav");
        let $allLis=$("[role='presentation']",$ul);
        //3.1遍历
        let tatolW=0;
        $allLis.each(function(index,item){
            tatolW+=$(item).width();
        });
        let parentW=$ul.parent().width();
        //3.2设置宽度
        if(tatolW > parentW){
            $ul.css({
                width:tatolW+"px"
            })
        }else{
            $ul.removeAttr("style");
        }
    });
    $(window).trigger("resize");

    //4.导航处理
    let allLis=$("#lk_nav li");
    $(allLis[2]).on("click",function(){
        $("html,body").animate({scrollTop:$("#lk_hot").offset().top},1000)
    })


})